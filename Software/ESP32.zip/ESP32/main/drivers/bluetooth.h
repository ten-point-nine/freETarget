/*----------------------------------------------------------------
 *
 * bluetooth.h
 *
 * Header file for Bluetooth.c
 *
 *---------------------------------------------------------------*/
#ifndef _BLUETOOTH_H_
#define _BLUETOOTH_H_

/*
 * Global functions
 */

void BlueTooth_configuration(void);        // Configure the BlueTooth module
void Bluetooth_start_new_connection(void); // New Bluetooth connection

#endif
